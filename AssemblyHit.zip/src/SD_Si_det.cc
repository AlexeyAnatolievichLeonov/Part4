#include "SD_Si_det.hh"
#include<G4OpticalPhoton.hh>

SD_Si_det :: SD_Si_det (G4String SDname) : G4VSensitiveDetector(SDname)
{
// collectionName.insert("SDhitSi_detCollection");

 G4String filename[10], filename1[3];
 char str[2];
 G4int i;
 for (i=0;i<10;i++)
 {
  filename[i] ="hit_Si_det_";
  sprintf(str,"%d",i+1);
  filename[i]+=str;
  filename[i]+=".dat";
//  G4cout<<filename[i]<<" "<<G4endl;
  hit_SD_Si_det[i].open(filename[i],std::fstream::out);
 }
 for (i=0;i<3;i++)
 {
  filename1[i] ="hit_Si_Assembly_";
  sprintf(str,"%d",i+1);
  filename1[i]+=str;
  filename1[i]+=".dat";
//  G4cout<<filename[i]<<" "<<G4endl;
  hit_SD_Si_Assembly[i].open(filename1[i],std::fstream::out);
 }
 for (i=0; i<10; i++) {SumE[i]=0.;}
 for (i=0; i<3; i++) {SumE_Assembly[i]=0.;}
}

SD_Si_det :: ~SD_Si_det()
{
 for (G4int i=0; i<10; i++) {hit_SD_Si_det[i].close();}
 for (G4int i=0; i<3; i++) {hit_SD_Si_Assembly[i].close();}
}

extern G4int eventID;

void SD_Si_det :: EndOfEvent(G4HCofThisEvent*)
{
 for (G4int i=0; i<10; i++)
 {hit_SD_Si_det[i] << std::setw(10) << SumE[i] << std::setw(10) << this->GetCopyNum(i+1) << G4endl;}
 for (G4int i=0; i<10; i++)
 {SumE[i]=0.;}
 for (G4int i=0; i<3; i++)
 {hit_SD_Si_Assembly[i] << std::setw(10) << SumE_Assembly[i] << std::setw(10) << this->GetCopyNum_Assembly(i+1) << G4endl;}
 for (G4int i=0; i<3; i++)
 {SumE_Assembly[i]=0.;}
}

G4bool SD_Si_det :: ProcessHits(G4Step* step, G4TouchableHistory*)
{
 G4TouchableHandle touchable = step->GetPreStepPoint()->GetTouchableHandle();
 G4int copyNo     = touchable->GetVolume(0)->GetCopyNo();
 G4String LogName = touchable->GetVolume(0)->GetLogicalVolume()->GetName();

 G4double edep  = 0.;
 edep           = step->GetTotalEnergyDeposit();
 if (strcmp(LogName,"Si_det_vol_log")==0)
 {
//  G4String pname = step->GetTrack()->GetDynamicParticle()->GetDefinition()->GetParticleName();
//  G4double time_ = step->GetPreStepPoint()->GetGlobalTime();
//  edep           = step->GetTrack()->GetDynamicParticle()->GetTotalEnergy()*1e6;
  this->SetCopyNum(copyNo);
  this->AddSumE(edep,copyNo);
 }
 if (strcmp(LogName,"Si_det_vol_log1")==0)
 {
  this->SetCopyNum_Assembly(copyNo);
  this->AddSumE_Assembly(edep,copyNo);
 }
 return true;
}

