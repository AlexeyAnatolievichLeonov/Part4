#ifndef SD_Si_det_HH
#define SD_Si_det_HH

#include <G4Material.hh>
#include "G4NistManager.hh"

#include "G4VSensitiveDetector.hh"
#include "G4Step.hh"
#include "G4HCofThisEvent.hh"
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdio.h>

class SD_Si_det : public G4VSensitiveDetector
{
 public:
  SD_Si_det(G4String SDname);
  ~SD_Si_det();

  G4bool ProcessHits(G4Step* astep, G4TouchableHistory*);

  void EndOfEvent(G4HCofThisEvent* HCE);

  G4double GetSumE(G4int i) const {return SumE[i];}
  void AddSumE(double e, G4int i) {SumE[i]+=e;}
  
  G4double GetCopyNum0(G4int i) const {return CopyNum0[i];}
  void SetCopyNum0(G4int i) {CopyNum0[i]=i+1;}
  G4double GetCopyNum1(G4int i) const {return CopyNum1[i];}
  void SetCopyNum1(G4int i) {CopyNum1[i]=i+1;}
  G4double GetCopyNum2(G4int i) const {return CopyNum2[i];}
  void SetCopyNum2(G4int i) {CopyNum2[i]=i+1;}
  
  G4ThreeVector GetLocal(G4int i) const {return local[i];}
  void SetLocal(G4ThreeVector vector1, G4int i) {local[i]=vector1;}
  G4ThreeVector GetWorld(G4int i) const {return world[i];}
  void SetWorld(G4ThreeVector vector1, G4int i) {world[i]=vector1;}
 private:
  std::ofstream hit_SD_Si_det[10];
  G4double SumE[10];
  G4int CopyNum0[10];
  G4int CopyNum1[10];
  G4int CopyNum2[10];
  G4ThreeVector world[10], local[10];
};

#endif
